const express = require('express')
require('dotenv').config()

const app = express();

const bookRoutes = require(`./routes/bookRoutes`);
const db = require('./config/db');

app.use(express.json()); // Middleware to parse JSON bodies

db.connect((err) => {
    if (err) throw err;
    console.log('Connected to MySQL Database!');
});

app.use(`/books`, bookRoutes)


const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));