const mysql = require('mysql2');

// 1. Create Connection
const pool = mysql.createConnection({
    host: 'localhost',
    user: 'sreeraj',      // Replace with your MySQL username
    password: '12345',      // Replace with your MySQL password
    database: 'bookstore'
});

// We export the .promise() version so we can use async/await
module.exports = pool.promise();