const db = require("../config/db");


//GET AL BOOKS
const getBooks = async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM books');
        res.json(rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Error fetching books" });
    }
};


// ADD BOOK
const createBook = async (req, res) => {
    try {
        const { title, author, published_year } = req.body;

        const sql = 'INSERT INTO books (title, author, published_year) VALUES (?, ?, ?)';

        // We await the execution. 'result' contains the insertId.
        const [result] = await db.query(sql, [title, author, published_year]);
        res.status(201).json({
            message: "Book added successfully!",
            bookId: result.insertId
        });
    } catch (error) {
        console.error("Error adding book:", error);
        res.status(500).json({ message: "Failed to add book" });
    }
}

// UPDATE BOOK
const updateBook = async (req, res) => {
    try {
        const { id } = req.params;
        const { title, author, published_year } = req.body;

        const sql = 'UPDATE books SET title = ?, author = ?, published_year = ? WHERE id = ?';
        const [result] = await db.query(sql, [title, author, published_year, id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Book not found" });
        }

        res.json({ message: "Book updated successfully" });
    } catch (error) {
        console.error("Error updating book:", error);
        res.status(500).json({ message: "Failed to update book" });
    }
};

// DELETE BOOK
const deleteBook = async (req, res) => {
    try {
        const { id } = req.params;
        const sql = 'DELETE FROM books WHERE id = ?';
        const [result] = await db.query(sql, [id]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "Book not found" });
        }

        res.json({ message: "Book deleted successfully" });
    } catch (error) {
        console.error("Error deleting book:", error);
        res.status(500).json({ message: "Failed to delete book" });
    }
};

module.exports = { getBooks, createBook, updateBook, deleteBook };
