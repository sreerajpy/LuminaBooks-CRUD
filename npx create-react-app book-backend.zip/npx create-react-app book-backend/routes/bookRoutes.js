const express = require(`express`)
const router = express.Router()
const { getBooks, createBook, updateBook, deleteBook } = require('../controlers/bookControlers')
const bookValidation = require('../validation/bookValidation')

router.get('/', getBooks);
router.post('/', bookValidation, createBook);
router.put('/:id', bookValidation, updateBook); 
router.delete('/:id', deleteBook);


module.exports = router