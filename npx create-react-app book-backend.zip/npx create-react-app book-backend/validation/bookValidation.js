module.exports = (req, res, next) => {
      const { title, author } = req.body;
    console.log("req.body", req.body);
    if (!title?.trim() || !author?.trim()) {
        return res.status(400).json({ message: "Title and Author are required" });
    }
    
      next();
};
